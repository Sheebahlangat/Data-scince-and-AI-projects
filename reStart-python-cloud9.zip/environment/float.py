myvalue=3.14
print(myvalue)
print(type(myvalue))
print(str(myvalue) + " is of the data type " + str(type(myvalue)))